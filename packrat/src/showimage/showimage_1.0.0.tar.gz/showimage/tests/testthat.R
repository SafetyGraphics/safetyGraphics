library(testthat)
library(showimage)

test_check("showimage")
