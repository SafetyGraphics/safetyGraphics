library(testthat)
library(selectr)

test_check("selectr")
