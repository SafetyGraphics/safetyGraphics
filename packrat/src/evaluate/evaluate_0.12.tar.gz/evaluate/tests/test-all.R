library(evaluate)

if (require("testthat", quietly = TRUE)) test_check("evaluate")
