par(mfrow = c(2, 2))
plot(1)
plot(2)
plot(3)
