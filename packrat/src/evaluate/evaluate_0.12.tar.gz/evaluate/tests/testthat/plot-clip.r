plot(rnorm(100), rnorm(100))
clip(-1, 1, -1, 1)
points(rnorm(100), rnorm(100), col = 'red')
