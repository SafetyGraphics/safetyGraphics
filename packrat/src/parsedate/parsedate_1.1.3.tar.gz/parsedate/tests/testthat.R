library(testthat)
library(parsedate)

test_check("parsedate")
