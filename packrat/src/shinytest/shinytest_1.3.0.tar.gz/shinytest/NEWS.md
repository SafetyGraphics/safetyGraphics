1.3.0
=====

* First public release
