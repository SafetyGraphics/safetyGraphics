#' @keywords internal
#' @importFrom glue glue
#' @import fs
"_PACKAGE"
