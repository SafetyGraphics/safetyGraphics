library(testthat)
library(debugme)

test_check("debugme")
