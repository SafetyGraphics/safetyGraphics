
#include "../processx.h"

SEXP processx_disable_crash_dialog() {
  /* TODO */
  return R_NilValue;
}
